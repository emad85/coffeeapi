console.log("****** start testing *******");
require('dotenv').config(); 